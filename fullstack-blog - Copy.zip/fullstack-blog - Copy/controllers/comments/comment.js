 const Post = require("../../model/post/post");
 const User = require("../../model/user/user");
 const Comment = require("../../model/comment/comment");
const appErr = require("../../utils/appErr");
 //created comment
 const CommentCreateCtrl= async(req,res,next)=>{
    const {message}= req.body
    
    try {
        const post = await Post.findById(req.params.id);
        //create a comment 
        const comment = await Comment.create({
            user: req.session.userAuth,
            message,
            post: post._id,
        });
        // push the comment 
        post.comments.push(comment._id);
        // find the user 
        const user = await User.findById(req.session.userAuth);
        //push the comment 
        user.comments.push(comment._id)
        //disable the validation 
        //save
        await post.save({ValidateBeforeSave: false});
        await user.save({ValidateBeforeSave: false});
        console.log(post);
         // redirect
         res.redirect("/api/v1/posts/${posts._id}");
    } catch (error) {
         next(appErr(error));
    }
}

 
//get /api/ v9/comments/:id
 const commentDetailsCtrl = async(req,res,next )=>{
    try {
        const comment = await Comment.findById(req.params.id);
        res.render("comments/updateComment", {
            comment, error: " "
        })
        
    } catch (error) {
        res.render("comments/updateComment", {
             error:  error.message,
        })
    }
};

//delete /api/ v9/comments/:id
  const commentDeleteCtrl = async(req,res,next)=>{
       console.log(req.query.postId);
    try {
        const comment = await Comment.findById(req.params.id);
        //check if comment belog to the user 
        if(comment.user.toString()!==req.session.userAuth.toString()){
            return next(appErr("You are not allow to delete this comment ", 403 ))

        }
        //delete comment 
        await Comment.findByIdAndDelete(req.params.id);
        // redirect
        res.redirect("/api/v1/posts/${req.query.postId}");
    } catch (error) {
         next(appErr(error))
    }
}

//put /api/ v9/comments
  const commentUpdateCtrl= async(req,res,next)=>{
    try {
        const comment = await Comment.findById(req.params.id);
        //check if comment belog to the user 
        if(comment.user.toString() != req.session.userAuth.toString()){
            return next(appErr("You are not allowed to update this comment ", 403));
        }
        //update
        const commentUpdate = await Comment.findByIdAndUpdate(req.params.id,{

         message: req.body.message,
        },{
            new:true,
        });
         // redirect
         res.redirect("/api/v1/posts/${req.query.postId}");
    } catch (error) {
        next(appErr(error));
    }
}
module.exports = {
    CommentCreateCtrl,
    commentDetailsCtrl,
    commentDeleteCtrl,
    commentUpdateCtrl,

}