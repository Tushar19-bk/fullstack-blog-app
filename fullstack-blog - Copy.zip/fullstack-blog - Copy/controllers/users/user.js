const bcrypt = require("bcryptjs");
const User =require("../../model/user/user") ;
 const appErr =require("../../utils/appErr.js")
// register
const registerCtrl = async(req,res ,next)=>{
    const {fullname,email,password} = req.body;
    
    //check if all filed required o

    if(!fullname || !email || !password){
        return  res.render("users/register",{
            error: "All field are require",
        });
    }
    try {
        // check if user exit with (email)
        const userFound = await User.findOne({email});
       // throw an error
       if(userFound){
        return  res.render("users/register",{
            error: " User already Exist",
        });
    
       }
       // Hash password 
       const salt = await bcrypt.genSalt(10);
       const passwordHashed = await bcrypt.hash(password , salt)

       //register user
       const user = await User.create({
        fullname,
        email,
         password : passwordHashed,
       });
        //redirect 
        res.redirect("/api/v1/users/profile-page")
    } catch (error) {
        res.json(error);
    }
}

 const loginCtrl = async(req,res,next)=>{
 
    const {email,password} = req.body;
    if(!email || !password){
        
        return  res.render("users/login",{
            error: "Email and password field are require",
        });
    }
    try {
        //check if email exit 
        const userFound = await User.findOne({email});
        if(!userFound){
            //thow error
            return  res.render("users/login",{
                error: "Invalid login Credentials",
            });
        
  }        

    // verify the password 
    const isPasswordValid = await bcrypt.compare(password,userFound.password);
    if(!isPasswordValid){
        //throw error
        return  res.render("users/login",{
            error: "Invalid login Credentials",
        });

}
// save  the user into session 
req.session.userAuth = userFound._id;

 //redirect 
  res.redirect("/api/v1/users/profile-page")
  } catch (error) {
  res.json(error);
 }
 };

//GET /api/ v9/users/:id
  const userDetailCtrl = async(req,res,next)=>{
    try {
        const userID  = req.params.id;
        // find the user 
        const  user = await User.findById(userID)
         
        res.render("users/updateUser",{
            user ,
            error:""
        })
    } catch (error) {
        res.render("users/updateUser",{
            error: error.message,
            user: " "
             
        })
       
    }
}

//GET /api/ v9/users/profile/:id
  const profileCtrl =async(req,res,next)=>{
    try {
        //get the login user 
        const userID = req.session.userAuth;
        // find the user 
        const user = await User.findById(userID).populate("posts").populate("comments");
        res.render("users/profile",{
            user,
            error:"",
        });
        
    } catch (error) {
        next(appErr(error.message)) ;
       
    }
}

//put/api/ v9/users/profile-photo-upload/:id
 const uploadProfilePhotoCrtl= async(req,res,next)=>{
    try {
        //check if file exit 
        if(!req.file){
         return  res.render("users/uploadProfilePhoto",{
            error:"please upload the photo"
           });
        }
        //1 find the user to updated 
        const userId = req.session.userAuth;
        const userFound = await User.findById(userId).populate("posts");
        // 2. check if user is found 
        if(!userFound){
            return  res.render("users/uploadProfilePhoto",{
                error:"User not found "});
        }
        // 3. update profile photo 
        await User.findByIdAndUpdate(userId,{
            profileImage: req.file.path,
        }, {new:true});
        //redirect 
     res.redirect("/api/v1/users/profile-page")
    } catch (error) {
        return  res.render("users/uploadProfilePhoto",{
            error:error.message});
    }
}
 
//put /api/ v9/users/cover-photo-upload/:id 
 const uploadCoverImgCtrl = async(req,res,next)=>{
     
    try {
        if(!req.file){
            return  res.render("users/uploadProfilePhoto",{
               error:"please upload the photo"
              });
           }
        //1 find the user to updated 
        const userId = req.session.userAuth;
        const userFound = await User.findById(userId);
        // 2. check if user is found 
        if(!userFound){
            return  res.render("users/uploadProfilePhoto",{
                error:"User not found "});
        }
        // 3. update profile photo 
        await User.findByIdAndUpdate(userId,{
            coverImage: req.file.path,
        }, {new:true});
        
       // /redirect 
     res.redirect("/api/v1/users/profile-page") 
    } catch (error) {
        return  res.render("users/uploadProfilePhoto",{
            error:error.message});
    }
}

//put/api/ v9/users/update-password 
 const updatePasswordCtrl = async(req,res,next)=>{
    const {password } = req.body ;
    try {
        if(password){
            const salt = await bcrypt.genSalt(10);
            const passwordHashed = await bcrypt.hash(password , salt);
                 // update user 
                 await User.findByIdAndUpdate(
                    req.session.userAuth,
                    {password:passwordHashed},{new:true,})
                 }
            //redirect 
           res.redirect("/api/v1/users/profile-page")
            
          
    
    } catch (error) {
        return  res.render("users/uploadProfilePhoto",{
            error: error.message});
    }
}
// put /api/v1/users/update/:id
  const updateuserCtrl = async(req,res,next)=>{
    const {fullname,email} = req.body;

    try {
        if(!fullname || !email){
            return res.render("users/updateUser",{
                error: "please provide details ",
                user:""
            })
        }
        //  check if email is not taken 
        if(email){
            const emailTaken = await User.findOne({email});
            if(emailTaken){
                return  res.render("users/updateUser",{
                    error:"email is taken ",user:""
                } );
                    
                    
            }
        }
        //update user 
          await User.findByIdAndUpdate(req.session.userAuth,{
            fullname,
            email,
        },{
            new: true,
        });
             //redirect 
     res.redirect("/api/v1/users/profile-page") ;
    } catch (error) {
        return  res.render("users/updateUser",{
            error:error.message,
        user:""});
    }
}


//get/api/ v9/users/logout 
 const logoutCtrl=  async(req,res)=>{
    req.session.destroy(()=>{
        res.redirect("/api/v1/users/login");
    });
}
 
 
module.exports = {
    registerCtrl,
    loginCtrl,
    userDetailCtrl,
    profileCtrl,
    uploadProfilePhotoCrtl,
    uploadCoverImgCtrl,
    updatePasswordCtrl ,
    updateuserCtrl,
    logoutCtrl,

};