
const Post = require("../../model/post/post");
 const post = require("../../model/post/post");
const User = require("../../model/user/user");
const appErr = require("../../utils/appErr");

 const CreatCtrl = async(req,res,next)=>{
   
    const {title, description,category, user,image}= req.body
    try {
        if(!title ||!description || !category ||!req.file){
            return res.render("posts/addPost",{error: "All field are require"})
        }
        //find the user 
        const userId = req.session.userAuth;
         const userFound = await User.findById(userId);
         // create the post 
         const postCreated = await post.create({
            title,
            description,
            category,
            user: userFound._id,
            image:req.file.path,
         });
         // push the post created into the array of users posts
         userFound.posts.push(postCreated._id);
         //resave the user details 
         await userFound.save();
        res.json({
            status:"succes",
            data: postCreated,
        });
        res.redirect("/")
    } catch (error) {
         
         return res.render("posts/addPost",{error: error.message})
    }
}

//get /api/ v9/posts
 const postlistCtrl = async(req,res,next)=>{
   

 try {
    const id = req.params.id;  
    const post = await post.findById(id).populate({
        path:"comments",
        populate:{
            path:"user"
        },
    } ).populate("user") ;
    console.log(post);
     res.render("posts/postDetails",{
        post,
        error:" ",
     })
} catch (error) {
      next(appErr(error.message))
}
}


//get /api/ v9/posts/:id
 const postDetailCtrl = async(req,res,next)=>{
    try {
        // get the id from params 
        const id = req.params.id;
        // find the post
        const post = await Post.findById(id).populate("comments");
        res.render("posts/postDetails",{
            post,
            error:"",
        });
    } catch (error) {
        return  res.render("posts/postDetails",{
            error: error.message,
        post:" "     });
    }  
} ;  
 
//delete /api/ v9/posts/:id
 const postDeleteCtrl = async(req,res,next)=>{
    try {
        // find the post 
        const post = await Post.findById(req.params.id);
        // check if the post belog to the user 
        if(post.user.toString() !== req.session.userAuth.toString()){
            return  res.render("posts/postDetails",{
                error:"you are not allow to delete this post ",
                post,

            });
        }
        //delete a post 
         await Post.findByIdAndDelete(req.params.id);
         //redirect
         res.redirect("/");
    } catch (error) {
        return  res.render("posts/postDetails",{
            error: error.message,
        post:" "     });
    }
}

//put /api/ v9/posts
 const postUpdateCtrl = async(req,res,next)=>{
    const {title,description,category}  = req.body 
    try {
        // find the post 
        const post = await Post.findById(req.params.id);
         // check if the post belog to the user 
         if(post.user.toString()  !== req.session.userAuth.toString() ){
            return res.render("posts/updatePost",{
                post:"",
                error:" You are Not authorized to update",

            });
        }
            // check if user is updating image 
            if(req.file){
                await Post.findByIdAndUpdate(
                    req.params.id , {
                    title,
                    description,
                    category,
                    image : req.file.path
                },{new:true})
            }else{  
                await Post.findByIdAndUpdate(
                req.params.id , {
                title,
                description,
                category,
        
            },{new:true})}
        
        
         
        // redirect 
        res.redirect("/")
    } catch (error) {
        return res.render("posts/updatePost",{
            post:"",
            error: error.message,

        });
    }
}

module.exports = {
    CreatCtrl,
    postlistCtrl,
    postDetailCtrl,
    postDeleteCtrl,
    postUpdateCtrl,

}
