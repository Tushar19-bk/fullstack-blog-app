const express =require("express");
const multer =require("multer");
const storage = require("../../config/cloudinary");
 const Post = require("../../model/post/post")

const {
    CreatCtrl,
    postlistCtrl ,
    postDetailCtrl,
    postDeleteCtrl,
    postUpdateCtrl,

} = require("../../controllers/posts/post");
const protected = require("../../middlewares/protected");
const postRoutes = express.Router();
 
//instance of multer 
const upload = multer({
    storage,
});

// forms
postRoutes.get("/get-post-form",(req,res)=>{
    res.render("posts/addPost",{error:" "})
});

postRoutes.get("/get-form-update/:id" , async(req,res)=>{
    try {
        const  post = await Post.findById(req.params.id);
        res.render("posts/updatePost",{post,error:""})
    } catch (error) {
        res.render("posts/updatePost", {error, post:""});
    }
});
postRoutes.post("/", protected , upload.single("file"),CreatCtrl );

//get /api/ v9/posts
postRoutes.get("/",  postlistCtrl);

//get /api/ v9/posts/:id
postRoutes.get("/:id",postDetailCtrl );

//delete /api/ v9/posts/:id
postRoutes.delete("/:id",protected,postDeleteCtrl);

//put /api/ v9/posts
postRoutes.put("/:id", protected, upload.single("file") ,postUpdateCtrl );
 
module.exports = postRoutes;