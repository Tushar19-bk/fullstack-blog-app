const express =require("express");
const multer = require("multer")
const storage = require("../../config/cloudinary");
const { registerCtrl,
    loginCtrl,
    userDetailCtrl,
    profileCtrl,
    uploadProfilePhotoCrtl,
    uploadCoverImgCtrl,
    updatePasswordCtrl ,
    updateuserCtrl,
    logoutCtrl, }= require("../../controllers/users/user");
    const protected = require("../../middlewares/protected");
const userRoutes = express.Router();

// instance of multer '
const upload = multer({storage})

//Rendering form 
// login form 
userRoutes.get("/login",(req,res)=>{
    res.render("users/login",{error:""})
});
// register form 
userRoutes.get("/register",(req,res)=>{
    res.render("users/register",{error:""})
});
 
//  upload profile Image  template 
userRoutes.get("/upload-profile-photo-form",(req,res)=>{
    res.render("users/uploadProfilePhoto",{error:" "});
});

//  upload cover Image  template 
userRoutes.get("/upload-cover-photo-form",(req,res)=>{
    res.render("users/coverProfilePhoto",{error:" "});
});

//   update user form  template 
userRoutes.get("/update-user-password",(req,res)=>{
   res.render("users/UpdatePassword",{error:""});
});



userRoutes.post("/register",upload.single("profile"), registerCtrl);
//post /api/ v9/users/login 
 userRoutes.post("/login", loginCtrl);

//GET /api/ v9/users/profile/:id
userRoutes.get("/profile-page",protected,profileCtrl )

//put/api/ v9/users/profile-photo-upload/:id
userRoutes.put("/profile-photo-upload",protected,upload.single("profile"), uploadProfilePhotoCrtl );

//put /api/ v9/users/cover-photo-upload/:id 
userRoutes.put("/cover-photo-upload",protected, upload.single("profile"), uploadCoverImgCtrl );

//put/api/ v9/users/update-password 
userRoutes.put("/update-password", updatePasswordCtrl);
// put /api/v1/users/update/:id
userRoutes.put("/update", updateuserCtrl);
//get/api/ v9/users/logout 
userRoutes.get("/logout",  logoutCtrl) ;
//GET /api/ v9/users/:id
userRoutes.get("/:id",userDetailCtrl );
 
 


module.exports = userRoutes;