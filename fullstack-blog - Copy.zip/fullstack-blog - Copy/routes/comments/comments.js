const express =require("express");

const commentRoutes = express.Router();
const {
    CommentCreateCtrl,
    commentDetailsCtrl,
    commentDeleteCtrl,
    commentUpdateCtrl,

} = require("../../controllers/comments/comment");
  const protected =require("../../middlewares/protected");
commentRoutes.post("/:id", protected ,CommentCreateCtrl);

//get /api/ v9/comments/:id
commentRoutes.get("/:id",commentDetailsCtrl);

//delete /api/ v9/comments/:id
commentRoutes.delete("/:id",protected,commentDeleteCtrl );

//put /api/ v9/comments
commentRoutes.put("/:id",protected,commentUpdateCtrl);

module.exports = commentRoutes;