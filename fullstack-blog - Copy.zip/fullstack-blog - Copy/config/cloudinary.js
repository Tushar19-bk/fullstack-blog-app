const dotenv = require("dotenv");
dotenv.config({path:"./utils/sec.env"});

const cloudinary = require("cloudinary").v2 ;
const {CloudinaryStorage} = require("multer-storage-cloudinary") ;

// configure cloudnary 
cloudinary.config({
    cloud_name: process.env.CLOUDINARY_NAME,
    api_key:  process.env.CLOUDINARY_kEY,
    api_secret : process.env.CLOUDINARY_SECRET_KEY
}) ;

// instance of cloudinary 

const storage = new  CloudinaryStorage({
    cloudinary,
    allowedformate: ["jpg","jpeg","png"],
    params:{
        folder:'blog-app-v9',
        transformation:[{width:500,height:500,croup:"limits"}]
    }
});

module.exports = storage;